/**
 * Created by Zac on 4/28/2015.
 */
public class Thread_A extends Thread {
    int k;
    public Thread_A(int k){
        this.k = k;
    }
    public void run() {
        //Run your program here.
    }
}

