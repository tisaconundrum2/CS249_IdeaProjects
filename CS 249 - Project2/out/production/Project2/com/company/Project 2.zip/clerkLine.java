package com.company;
/*
 * Author: Nicholas Finch
 * CS 249
 * 10/17/14
 * Collaborated with Doug
 */

public class clerkLine {
    public int[] person;
    public int size;
    public int count = 0;
    //======================================================
    public clerkLine(int maxSize){
        person = new int[maxSize];
        size = maxSize;
    }
    //======================================================
    public void insert(int newCustomer){
        if (count > size) System.out.println("The line is full!");
        else person[count++] = newCustomer;
    }
    //======================================================
    public void incrementTime(){
        person[0] = person[0] -1;
        if (person[0] <= 0)
            remove();
    }
    //======================================================
    public void remove(){
        if (!isEmpty()) {
            int[] temp = new int[size + 1];
            for (int i = 0; i < size - 1; i++)
                temp[i] = person[i + 1];
            for (int i = 0; i < size; i++)
                person[i] = temp[i];
            count--;
        }
    }

    private boolean isEmpty() {
        return (count==0);
    }

    //======================================================
    public void display(){
        for (int i = 0; i < size; i++){
            System.out.print("[" + person[i] + "]");
        }
    }
}//end clerkLine

