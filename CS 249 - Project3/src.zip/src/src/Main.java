package src;

class LinkList2App
{
    public static void main(String[] args)
    {
        matrixList theList = new matrixList(5, 11);
        theList.insertRight(04,10);
        theList.insertRight(03,9);
        theList.insertRight(02,8);
        theList.insertRight(01,7);

    } // end main()
} // end class LinkList2App