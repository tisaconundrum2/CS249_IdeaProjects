//package com.company;
//
///**
// * Created by User on 10/29/2014.
// */
//public class Node {
//    public long iData;
//    public double dData;
//    public Node isRight;    //to the right of current Node
//    public Node isBelow;    //below the current Node
//
//    public Node(long id, double dd){
//        iData = id;
//        dData = dd;
//    }//endNode
//    public void displayNode() {     // display yourself
//        System.out.print("{"+iData + ","+dData + "}");
//    }
//}//end Class
